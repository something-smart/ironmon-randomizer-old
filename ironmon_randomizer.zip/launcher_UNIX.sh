cd "$( dirname "$0" )"
java -Xmx4608M -jar ironmon_randomizer.jar please-use-the-launcher